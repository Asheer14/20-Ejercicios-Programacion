/*Desarrollar un ejercicio que muestre los n�meros del 1 al 100.*/
#include<iostream>
using namespace std;
int main (){
	int i;
	
	for(i=1; i<=100; i++){
		cout<<i<<endl;
	}
	return 0;
}

