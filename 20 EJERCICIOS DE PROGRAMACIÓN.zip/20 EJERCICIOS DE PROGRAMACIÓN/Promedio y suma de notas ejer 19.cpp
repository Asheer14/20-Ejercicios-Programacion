/*Ingresar la cantidad de notas de un estudiante, 
el programa finalizar� hasta que se ingrese una nota 
Negativa, el programa mostrar�
el promedio y sumatoria de los n�meros ingresados. */
#include<iostream>
using namespace std;
int main(){
	int num1,a=99,num2,b=100,num3,c=98,num4,d=78,num5,e=89,promedio,suma;
	
	
	cout<<"Ingrese la nota de Ingles"<<endl;
	cin>>num1;
	cout<<"Ingrese la nota de Sociologia"<<endl;
	cin>>num2;
	cout<<"Ingrese la nota de Ciencias Sociales"<<endl;
	cin>>num3;
	cout<<"Ingrese la nota de Informatica"<<endl;
	cin>>num4;
	cout<<"Ingrese la nota de Lengua y Literatura"<<endl;
	cin>>num5;
	
	suma=(num1+num2+num4+num5);
	promedio=(num1+num2+num4+num5)/4;
	
	
	cout<<"La sumatoria es:"<<suma<<endl;
	cout<<"El promedio es:"<<promedio<<endl;
	
	if(num1==a){
		cout<<"El numero es 99";	
	}
	else{
		cout<<"El numero es incorrecto";
	}
	
	
	return 0;
}
