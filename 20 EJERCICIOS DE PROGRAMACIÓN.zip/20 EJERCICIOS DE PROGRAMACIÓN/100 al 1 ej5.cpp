/* Desarrollar un ejercicio que muestre los n�meros del 100 al 1.*/
#include<iostream>
using namespace std;
int main (){
	int i;
	
	for(i=100; i>=1; i--){
		cout<<i<<endl;
	}
	return 0;
}
