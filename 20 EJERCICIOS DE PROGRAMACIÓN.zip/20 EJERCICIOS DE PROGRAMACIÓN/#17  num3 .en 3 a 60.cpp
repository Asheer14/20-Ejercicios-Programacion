/*Elaborar un programa que muestre los n�meros de 3 en 3 hasta el 60*/
#include <iostream>
using namespace std;
int main()
{
    // Hacemos un ciclo desde 0 hasta 60
    for (int i = 0; i <= 60; i += 3)
    {
        cout << i << endl;
    }
    return 0;
}
